package logicGates;

abstract public interface  Printable {
    
    abstract void print();
    abstract void printTableHeader();
    
}
