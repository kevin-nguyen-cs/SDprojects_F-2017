# Software-Design
Projects for software design


9/16/2017 : PROJECT 2 FOLDER - added along with Project 2 related materials

9/22/2017 : PROJECT 3 FOLDER - added along with Project 2 related materials including MDELite7 and Yuml docs
