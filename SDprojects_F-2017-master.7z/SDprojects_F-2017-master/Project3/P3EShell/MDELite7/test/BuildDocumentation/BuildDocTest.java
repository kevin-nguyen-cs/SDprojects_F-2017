package BuildDocumentation;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map.Entry;
import org.junit.Test;

public class BuildDocTest {

    // this is a (marker, contents) hash map filled in by harvest()
    static HashMap<String, String> harvested = null;

    /**
     * create .html file outputHtml given a .htm BuildDocTest and the
     * sourceCodeFile (typically .java) from which to extract code. A marker is
     * " ---NAME--- " in an .htm template file A marker is "///NAME " in a
     * sourcecode file
     *
     * @param sourceCodeFileName -- file that has named begin+end markers
     * @param templateFile --- .htm file with named markers (where source code
     * is to be inserted)
     * @param outputHtml -- output .html file
     */
    public void main(String sourceCodeFileName, String templateFile, String outputHtml) {
        if (!templateFile.endsWith(".htm")) {
            throw new RuntimeException("template file \'" + templateFile + "' does not end in .htm");
        }
        if (!outputHtml.endsWith(".html")) {
            throw new RuntimeException("output file \'" + outputHtml + "' does not end in .htm");
        }
      
        harvestCode(sourceCodeFileName); // fills in harvest
        String htmlFile = inhale(templateFile); // fills in results
        for (Entry<String, String> e : harvested.entrySet()) {
            String key = "---" + e.getKey() + "---";
            if (htmlFile.contains(key)) {
                htmlFile = htmlFile.replace(key, e.getValue());
            }
        }
        exhale(htmlFile, outputHtml);
    }

    /**
     * scan sourceCodeFileName for ///Name ... ///Name parentheses
     * whatever is in between associate that with the contents of marker NAME
     * and place into HashMap harvested
     * @param sourceCodeFileName -- name of source code file to scan
     */
    static void harvestCode(String sourceCodeFileName) {
        harvested = new HashMap<>();
        LineNumberReader br;
        String markerName = null;
        String accum = null;
        int lineno = -1;
        try {
            br = new LineNumberReader(new InputStreamReader(new FileInputStream(new File(sourceCodeFileName))));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("///")) {
                    // first time through, get marker name and init accum
                    if (markerName == null) {
                        markerName = line.replace("///", "").trim();
                        accum = "";
                        continue;
                    } else {
                        // second time through erase marker name and save accum
                        harvested.put(markerName, accum);
                        markerName = null;
                        accum = null;
                        continue;
                    }
                }
                lineno = br.getLineNumber();

                if (markerName != null) {
                    accum = accum + line + "<br>";
                }
            }
            br.close();
        } catch (Exception e) {
            throw new RuntimeException("unable to parse " + sourceCodeFileName + " around line " + lineno + "\n" + e.getMessage());
        }
    }

    /**
     * return the String that is the content of the template file
     * @param templateFileName -- path to template file
     * @return -- string that is the contents of the Ht
     */
    public static String inhale(String templateFileName) {
        LineNumberReader reader = null;
        String accum = "", line,pattern;
        try {
            reader = new LineNumberReader(new InputStreamReader(new FileInputStream(new File(templateFileName))));
            while ((line = reader.readLine()) != null) {
                String tline = line.trim();
                if (tline.contains(":::")) {
                    String[] toks = tline.split(":::");
                    String filename = toks[1];
                    String contents = readFile(filename);
                    pattern = ":::"+filename+":::";
                    line = line.replace(pattern, contents);
                }
                accum += line + "\n";
            }
            reader.close();
        } catch (Exception e) {
            throw new RuntimeException("unable to read " + templateFileName + " at line " + reader.getLineNumber() 
                      +"\n" + e.getMessage());
        }
        return accum;
    }
    
    static String readFile(String filename) {
        String accum = "", line;
        try {
            LineNumberReader br = new LineNumberReader(new InputStreamReader(new FileInputStream(new File(filename))));
            while ((line = br.readLine()) != null) {
                accum += line + "\n";
            }
            br.close();
        } catch (Exception e) {
            throw new RuntimeException("unable to read " + filename + "\n" + e.getMessage());
        }
        return accum;
    }

    /**
     * write out string data to file HtmlFileName
     * @param data -- string of file contents
     * @param HtmlFileName -- name of file to write
     */
    static void exhale(String data, String HtmlFileName) {
        try {
            PrintStream out = new PrintStream(HtmlFileName);
            out.println(data);
            out.close();
        } catch (Exception e) {
            throw new RuntimeException("unable to write " + HtmlFileName + "\n" + e.getMessage());
        }
    }

    @Test
    public void test1() {
        main("test/DML/PrologDB/DocExamplesTest.java", "Docs/MDELiteDemoTemplate.htm", "Docs/MDELiteDemoPrograms.html");
    }

    @Test
    public void test2() {
        main("test/DML/PrologDB/DocConstraintExamplesTest.java", "Docs/MDELiteConstraintDemoTemplate.htm", "Docs/MDELiteConstraintDemoPrograms.html");
    }
}
