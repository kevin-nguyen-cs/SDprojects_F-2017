package Violet.Class;

public interface VioletClassTestConstants {
    static final String correct  = "test/Violet/Class/Correct/";
    static final String endViolet = ".class.violet";
    static final String endVpl = ".vpl.pl";
    static final String vplFile = "error"+endVpl;
    static final String violetFile = "error"+endViolet;
    static final String conformFile = "error.txt";
}
