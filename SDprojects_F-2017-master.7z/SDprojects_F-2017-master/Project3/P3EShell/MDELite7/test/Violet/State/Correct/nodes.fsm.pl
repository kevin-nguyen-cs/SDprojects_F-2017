dbase(fsm,[node,edge]).

table(node,[nid,ntype,"text","color",xpos,ypos]).
node(StateNode0,state,'1','',351.0,149.0).
node(StateNode1,state,'2','',576.0,163.0).
node(StateNode2,state,'3','',793.0,167.0).
node(Void0,init,'','',395.0,267.0).
node(Void1,init,'','',625.0,266.0).
node(Void2,init,'','',835.0,277.0).
node(Void3,final,'','',405.0,348.0).
node(Void4,final,'','',632.0,356.0).
node(Void5,final,'','',865.0,367.0).
node(NoteNode0,note,'3','',403.0,417.0).
node(NoteNode1,note,'4','',631.0,435.0).
node(NoteNode2,note,'5','255:140:0:255:',877.0,440.0).

table(edge,[eid,etype,"label",startid,endid]).

