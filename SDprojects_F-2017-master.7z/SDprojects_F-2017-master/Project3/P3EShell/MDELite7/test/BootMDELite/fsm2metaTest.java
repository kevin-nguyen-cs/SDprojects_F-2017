package BootMDELite;

import org.junit.Test;

public class fsm2metaTest {

    public static String errorFile = "error.txt";
    public static String normalFile = "error.meta.pl";
    public static final String Correct = "test/BootMDELite/Correct/";

    public fsm2metaTest() {
    }

    public void doit(String filename) {
        RegTest.Utility.redirectStdErr(errorFile);
        try {
            fsm2meta.main(Correct + filename + ".fsm.pl", normalFile);
            RegTest.Utility.validate(normalFile, Correct + filename + ".meta.pl", false);
            return;
        } catch (Exception e) {
            RegTest.Utility.validate(errorFile, Correct + filename + ".txt", false);
        }
    }

    @Test
    public void catalina() {
        doit("catalina");
    }

}
