package BootMDELite;

import org.junit.Test;
import static org.junit.Assert.*;

public class CatCSVParserTest {

    static final String correct = "test/BootMDELite/Correct/";
    static final String metaEnd = ".meta.pl";
    static final String metaDir = ".metadir";

    public CatCSVParserTest() {
    }

    public void doit(String dirName) {
        String result = dirName + metaEnd;
        try {
            CatCSVParser.main(correct + dirName + metaDir, result);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            fail();
        }
        RegTest.Utility.validate(result, correct + result, false);
    }

    @Test
    public void X() {
        doit("X");
    }

}
