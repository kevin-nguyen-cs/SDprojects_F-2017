package BootMDELite;

import org.junit.Test;

public class meta2javaTest {
    static final String correct = "test/bootMDELite/Correct/";
    static final String errorFile = "error.txt";
    static final String normalFile = "normal.java";
    
    public meta2javaTest() {
    }

    private void doit(String filename) {
        RegTest.Utility.redirectStdErr(errorFile);
        try {
            meta2java.main(correct+filename+".meta.pl", normalFile);
            RegTest.Utility.validate(normalFile, correct+filename+".txt", false);
            return;
        } catch (Exception e) {
            RegTest.Utility.validate(errorFile, correct+filename+".txt", false);
        }
    }
    
    @Test
    public void catalina() {
        doit("catalina");
    }
    
    @Test
    public void fsm() {
        doit("fsm");
    }
}
