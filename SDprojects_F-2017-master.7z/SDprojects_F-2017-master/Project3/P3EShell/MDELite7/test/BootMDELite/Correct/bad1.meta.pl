dbase(meta,[domain,arrow,path]).

table(domain,[id,"name","ext","conformExecutable",temp]).
domain(n1,'state','violet','',false).
domain(n2,'fsm','pl','Violett.StateConform',true).
domain(n3,'fsm','pl','BootMDELite.MetaConform',true).
domain(n1,'java','','',false).

table(arrow,[id,"name","domainInputs","domainOutput","javaExecutable"]).
arrow(a1,'parse','state','fsm','Violett.StateParser').
arrow(a2,'m2m','fsm','meta','BootMDELite.fsm2meta').
arrow(a2,'m2t','state','java','BootMDELite.meta2java').

table(path,[id,"name","path"]).
path(p1,'convert','parse;m2m;m2t').
path(p2,'validateMeta','parse;m2m').
path(p3,'validateViolet','parse').
path(p3,'validateViolet','parse').
