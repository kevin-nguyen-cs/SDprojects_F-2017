%BOGUS -- replaced arrow executables with dummies
dbase(meta,[domain,arrow,path]).

table(domain,[id,"name","ext","conformExecutable",temp]).
domain(n1,'state','violet','',false).
domain(n2,'fsm','pl','Violett.StateConform',true).
domain(n3,'java','','',false).

table(arrow,[id,"name","domainInputs","domainOutput","javaExecutable"]).
arrow(a1,'parse','state','fsm','Violett.StateParser').
arrow(a2,'NestSwitch','fsm','java','Violett.StateUnParser').
arrow(a3,'DesignPattern','fsm','java','Violett.StateUnParser').

table(path,[id,"name","path"]).
path(p1,'convertDP','parse;DesignPattern').
path(p2,'convertNS','parse;NestSwitch').
path(p3,'validate','parse').
