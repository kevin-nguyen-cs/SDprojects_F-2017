dbase(meta,[domain,arrow,path]).

table(domain,[id,"name","ext","conformExecutable",temp]).
domain(n1,'state','violet','',false).
domain(n2,'fsm','pl','Violet.StateConform1',true).
domain(n3,'meta','pl','BootMDELite.MetaConform',true).
domain(n4,'java','','',false).

table(arrow,[id,"name","domainInputs","domainOutput","javaExecutable"]).
arrow(a1,'parse','state','fsm','Violet.StateParser2').
arrow(a2,'m2m','fsm','meta','BootMDELite.fsm2meta').
arrow(a3,'m2t','meta','java','BootMDELite.meta2java1').

table(path,[id,"name","path"]).
path(p1,'convert','parse;m2m;m2t').
path(p2,'validateMeta','parse;m2m').
path(p3,'validateViolet','parse').
