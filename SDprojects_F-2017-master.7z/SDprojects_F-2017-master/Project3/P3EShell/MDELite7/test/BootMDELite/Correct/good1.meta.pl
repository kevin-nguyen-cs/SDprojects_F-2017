%  arrows with multiple inputs and multiple outputs

dbase(meta,[domain,arrow,path]).

table(domain,[id,"name","ext","conformExecutable",temp]).
domain(n1,'state','violet','',false).
domain(n2,'fsm','pl','Violett.StateConform',true).
domain(n3,'java','','',false).

table(arrow,[id,"name","domainInputs","domainOutput","javaExecutable"]).
arrow(a1,'parse','fsm,state','java','Yuml.ClassParser').
arrow(a2,'NestSwitch','fsm,java','fsm,java','Yuml.ClassParser').
arrow(a3,'DesignPattern','fsm,fsm','java,java','Yuml.ClassParser').

table(path,[id,"name","path"]).
path(p1,'convertDP','parse;DesignPattern').
path(p2,'convertNS','parse;NestSwitch').
path(p3,'validate','parse').
