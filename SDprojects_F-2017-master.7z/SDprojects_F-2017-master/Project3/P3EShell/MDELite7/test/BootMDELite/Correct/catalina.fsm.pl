dbase(fsm,[node,edge]).

table(node,[nid,ntype,"text","color",xpos,ypos]).
node(StateNode0,state,'state%%','',349.0,260.0).
node(StateNode1,state,'fsm%','',543.0,263.0).
node(StateNode2,state,'meta','',737.0,260.0).
node(StateNode3,state,'java%','',950.0,271.0).
node(NoteNode0,note,'paths%convert=parse;m2m;m2t%validateViolet=parse%validateMeta=parse;m2m','',896.0,381.0).
node(NoteNode1,note,'arrows%parse=Violett.StateParser%m2m=BootMDELite.fsm2meta%m2t=BootMDELite.meta2java%','',680.0,387.0).
node(NoteNode2,note,'domains%domain=state, ext=violet%domain=fsm, ext=pl, conform=Violett.StateConform, temp%domain=meta, ext=pl, conform=BootMDELite.MetaConform, temp%domain=java','',215.0,390.0).

table(edge,[eid,etype,"label",startid,endid]).
edge(e0,arrow,'parse',StateNode0,StateNode1).
edge(e1,arrow,'m2m',StateNode1,StateNode2).
edge(e2,arrow,'m2t',StateNode2,StateNode3).

