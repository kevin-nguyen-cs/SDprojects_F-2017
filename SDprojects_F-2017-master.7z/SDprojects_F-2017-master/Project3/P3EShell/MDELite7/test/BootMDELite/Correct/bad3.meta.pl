dbase(meta,[domain,arrow,path]).

table(domain,[id,"name","ext","conformExecutable",temp]).
domain(n1,'state','violet','',false).
domain(n2,'fsm','pl','Violett.StateConform',true).
domain(n3,'java','','',false).

table(arrow,[id,"name","domainInputs","domainOutput","javaExecutable"]).
arrow(a1,'parse','state','fsm','Violett.StateParser').
arrow(a2,'NestSwitch','fsm','java','Violett.StateParser').
arrow(a3,'DesignPattern','fsm','java','Violett.StateParser').

table(path,[id,"name","path"]).
path(p1,'convertDP','validater;DesignPattern').
path(p2,'convertNS','parse;NestSwitch').
path(p3,'validate','parse').
path(p4,'bogus','parser;skip').
