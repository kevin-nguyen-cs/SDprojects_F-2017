dbase(con,[company,contract,person]).
table(company,[cid,"name"]).
table(contract,[kid,value,cid,pid]).
table(person,[pid,"name"]).
