:-style_check(-discontiguous).

dbase(complex,[a,b]).

table(a,[id,bc,d,tob,"tobb"]).
a(1,2,3,4,'5').
a(2,3,4,5,'66').

table(b,[id,bc,d,tob,"tobb","b",c,toa,"toaa"]).
b(1,2,3,4,'5','z',2,3,'5').
b(2,3,4,5,'66','zzz',2,3,'5').

subtable(a,[b]).
