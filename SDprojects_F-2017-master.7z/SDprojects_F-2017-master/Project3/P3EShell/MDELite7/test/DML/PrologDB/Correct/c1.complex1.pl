dbase(complex1,[a,b]).

table(a,[id,bc,d,tob,"tobb",length]).
a(1,2,3,4,'5',1).
a(2,3,4,5,'66',2).

table(b,[id,bc,d,tob,"tobb","b",c,toa,"toaa",length]).
b(1,2,3,4,'5','z',2,3,'5',1).
b(2,3,4,5,'66','zzz',2,3,'5',2).

subtable(a,[b]).
