table(trans,[par,chd]).
trans(a,b).
trans(a,c).
trans(a,d).
trans(d,c).
