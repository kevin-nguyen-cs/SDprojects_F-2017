table(trans,[par,chd]).
trans(a,b).
trans(b,c).
trans(c,d).
trans(d,a).
