package DML.PrologDB;

import PrologDB.Constraints;
import PrologDB.DB;
import PrologDB.ErrorReport;
import PrologDB.Table;
import PrologDB.Tuple;
import PrologDB.Unique;
import java.util.HashMap;
import java.util.function.Predicate;
import org.junit.Test;

public class DocConstraintExamplesTest extends Constraints {
    static final String testdata = "test/DML/PrologDB/TestData/";
    static final String correct = "test/DML/PrologDB/Correct/";
    static final String errorfile = "error.txt";

    public DocConstraintExamplesTest() {
    }

    @Test
    public void nonNullFieldTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            NonNull();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"nonnull.txt", false);
    }

///NonNull
    void NonNull() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table takes = db.getTableEH("takes");
        ErrorReport er = new ErrorReport();
        
        // manual way
        testNull(takes, "cid", er);
        testNull(takes, "sid", er);
        
        // MDELite built-in support
        Predicate<Tuple> cidIsNull = t->t.isNull("cid");
        iftest(takes,cidIsNull,"cid is null",er);
        
        Predicate<Tuple> sidIsNull = t->t.isNull("sid");
        iftest(takes,sidIsNull,"sid is null",er);
        
        // finish
        er.printReport(System.out);
    }

    void testNull(Table tab, String fieldName, ErrorReport er) {
        tab.stream()
           .filter(t -> t.isNull(fieldName))
           .forEach(t -> er.add("%s(%s...) has null %s field", 
                tab.getName(), t.get("tid"), fieldName));
    }
///NonNull

    @Test
    public void existenceTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            Existence();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"existence.txt", false);
    }

///Existence
    void Existence() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table takes = db.getTableEH("takes");
        Table course = db.getTableEH("course");
        ErrorReport er = new ErrorReport();
        
        // Manual: one way -- a tuple at a time
        takes.stream()
             .filter(t -> (!course.exists("cid", t.get("cid"))))
             .forEach(t -> {
                er.add("takes(%s,..) has invalid cid value (%s)",
                       t.get("tid"), t.get("cid"));
                });
        
        // Manual: another way -- compute a table of offending tuples
        Table offendingTakes = Table.antiSemijoin(takes, "cid", course, "cid");
        offendingTakes
                .stream()
                .forEach(t-> er.add("takes(%s,..) has invalid cid value (%s)",
                        t.get("tid"), t.get("cid")));
        
        // MDELite built-in support
        isLegit(takes, "cid", course, "cid", er);
        
        // finish
        try {er.printReport(System.out);} catch (Exception ex) {}
        
    }
///Existence

    @Test
    public void uniqueIDTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            UniqueID();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"unique.txt", false);
    }

///UniqueID
    void UniqueID() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table course = db.getTableEH("course");
        ErrorReport er = new ErrorReport();
        
        // Manual
        Unique u = new Unique(course, "cid", er);
        course.stream().forEach(t -> u.add(t));
        
        // MDELite built-in support
        isUnique(course, "cid", er);
        
        // finish
        er.printReport(System.out);
    }
///UniqueID

    @Test
    public void uniqueNameTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            UniqueName();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"uniqueName.txt", false);
    }

///UniqueName
    void UniqueName() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table student = db.getTableEH("student");
        ErrorReport er = new ErrorReport();
        
        // Manual way
        Unique u = new Unique(student, "name", er);
        student.stream().forEach(t -> u.add(t));
        
        // MDELite built-in support
        isUnique(student, "name", er);
        
        // finally
        er.printReport(System.out);
    }
///UniqueName

    @Test
    public void uniqueComboTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            UniqueCombo();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"uniqueCombo.txt", false);
    }

///UniqueCombo
    void UniqueCombo() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table takes = db.getTableEH("takes");
        ErrorReport er = new ErrorReport();
        Unique u = new Unique(takes, "combo", er);

	// test for duplicates on artificial field
        for (Tuple t : takes.tuples()) {
            String c = combo(t);
            u.add(t,c);
        }

	// finally
        er.printReport(System.out);
    }

    String combo(Tuple t) {
        return "'" + t.get("cid") + "," + t.get("sid") + "'"; // quotes optional
    }
///UniqueCombo

    @Test
    public void attendanceTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            attendance();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"attendance.txt", false);
    }

///attendance
    void attendance() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table course = db.getTableEH("course");
        Table takes = db.getTableEH("takes");
        ErrorReport er = new ErrorReport();

	// check constraint
        course.stream()
          .filter(t -> t.is("name", "compilers") || t.is("name", "databases"))
          .filter(t -> t.join("cid", takes, "cid").size() < 2)
          .forEach(t -> er.add("%s course does not have enough students", t.get("name")));

	// finally
        er.printReport(System.out);
    }
///attendance    

    @Test
    public void jConstraintTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            jConstraint();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"jConstraint.txt", false);
    }


///jConstraint
    void jConstraint() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table student = db.getTableEH("student");
        Table takes = db.getTableEH("takes");
        Table course = db.getTableEH("course");
        ErrorReport er = new ErrorReport();

	// check constraint
        student.stream().forEach(s -> {
            Table shortTakes = s.rightSemiJoin("sid", takes, "sid");
            Table joined = Table.join(shortTakes, "cid", course, "cid");
            if (joined.size() == 0) {
                er.add("student %s is not taking a database course", s.get("name"));
            }
        });

	// finally
        er.printReport(System.out);
    }
///jConstraint 
    
    @Test
    public void jConstraint2Test() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            jConstraint2();
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"jConstraint.txt", false);
    }


///jConstraint2
    void jConstraint2() {
        DB db = DB.readDataBase(testdata+"/StudentCourse.sc.pl");
        Table student = db.getTableEH("student");
        Table takes = db.getTableEH("takes");
        Table course = db.getTableEH("course");
        Table tc = Table.join(takes,"cid", course, "cid");
        ErrorReport er = new ErrorReport();

	// check constraint
        student.stream()
               .filter(s -> s.rightSemiJoin("sid",tc,"takes.sid").size()==0)
               .forEach(s ->er.add("student %s is not taking a database course", 
                       s.get("name")));

	// finally
        er.printReport(System.out);
    }
///jConstraint2
    
    @Test
    public void joinTest() {
        RegTest.Utility.redirectStdOut(errorfile);
        try {
            HashMap<String,Integer> collection = new HashMap<>();
            DB db = DB.readDataBase(testdata+"/dogOwner.do.pl");
            ErrorReport er = new ErrorReport();
            
            Table dog = db.getTableEH("dog");
            Table dogc = dog.copyForSelfJoins("dogc");
            Table dxdc = Table.join(dog, "name", dogc, "name");
            for (Tuple t : dxdc.tuples()) {
                String key = t.get("dog.name");
                Integer i = collection.get(key);
                i = (i==null)? 1 : i + 1;
                collection.put(key,i);
            }
            for (String k : collection.keySet()) {
                Integer i = collection.get(k);
                if (i!=1)  {
                    er.add("%s has %d replicas", k, i/2);
                }
            }
            System.out.println("dogs with the same name");
            er.printReport(System.out);
                    
        } catch (Exception e) {
        }
        RegTest.Utility.validate(errorfile, correct+"jointest.txt", false);
    }
}
