Table violetMiddleLabels not in dbSchema violetdb
