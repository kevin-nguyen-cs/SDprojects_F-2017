dbase(complex,[a,b]).

table(a,[id,bc,d,tob,"tobb"]).
table(b,[id,bc,d,tob,"tobb","b",c,toa,"toaa"]).

subtable(a,[b]).

