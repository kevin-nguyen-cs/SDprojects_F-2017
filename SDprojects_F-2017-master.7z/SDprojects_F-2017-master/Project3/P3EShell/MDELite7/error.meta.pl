dbase(meta,[domain,arrow,path]).

table(domain,[id,"name","ext","conformExecutable",temp]).
domain(c0,'state','violet','',false).
domain(c1,'fsm','pl','Violett.StateConform',true).
domain(c2,'meta','pl','BootMDELite.MetaConform',true).
domain(c3,'java','','',false).

table(arrow,[id,"name","domainInputs","domainOutput","javaExecutable"]).
arrow(a0,'parse','state','fsm','Violett.StateParser').
arrow(a1,'m2m','fsm','meta','BootMDELite.fsm2meta').
arrow(a2,'m2t','meta','java','BootMDELite.meta2java').

table(path,[id,"name","path"]).
path(p0,'convert','parse;m2m;m2t').
path(p1,'validateViolet','parse').
path(p2,'validateMeta','parse;m2m').

