class city {
  String name;
  String state;
}

