class account {
  int number;
  double balance;
}

