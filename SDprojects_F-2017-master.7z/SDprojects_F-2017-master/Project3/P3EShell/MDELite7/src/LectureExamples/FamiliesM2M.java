package LectureExamples;

import MDELite.Marquee2Arguments;
import PrologDB.*;

public class FamiliesM2M {
    static final String correct = "test/LectureExamples/Correct/";

    public static void main(String... args) {
        String id, fullName;
        
        // Step 1: standard marquee processing
        Marquee2Arguments mark = new Marquee2Arguments(FamiliesM2M.class, ".families.pl", ".persons.pl", args);
        String inputFileName = mark.getInputFileName();
        String outputFileName = mark.getOutputFileName();
        
        // Step 2: read the families database and their tables
        DB in = DB.readDataBase(inputFileName);
        Table fam = in.getTableEH("family");
        Table mem = in.getTableEH("member");

        // Step 3: create an empty persons database with empty tables
        DBSchema outSchema = DBSchema.readSchema(correct+"persons.schema.pl");
        DB inria = new DB(in.getName(),outSchema);
        Table male = inria.getTableEH("male");
        Table female = inria.getTableEH("female");
        
        // Step 4: fill in father tuples
        Table father = Table.join(fam,"fatherid",mem,"mid");
        for (Tuple f : father.tuples()) {
            id = f.get("member.mid");
            fullName = f.get("member.firstName")+ " " +f.get("family.lastName");
            male.addTuple(id,fullName);
        }
        
        // Step 5: fill in mother tuples
        Table mother = Table.join(fam,"motherid",mem,"mid");
        for (Tuple m : mother.tuples()) {
            id = m.get("member.mid");
            fullName = m.get("member.firstName")+ " " +m.get("family.lastName");
            female.addTuple(id,fullName);
        }
        
        // Step 6: fill in son tuples
        Table sons = Table.join(fam,"id",mem,"sonOf");
        for (Tuple m : sons.tuples()) {
            id = m.get("member.mid");
            fullName = m.get("member.firstName")+ " " +m.get("family.lastName");
            male.addTuple(id,fullName);
        }
        
        // Step 7: fill in daughters tuples
        Table daughters = Table.join(fam,"id",mem,"daughterOf");
        for (Tuple m : daughters.tuples()) {
            id = m.get("member.mid");
            fullName = m.get("member.firstName")+ " " +m.get("family.lastName");
            female.addTuple(id,fullName);
        }
        
        // Step 8: print out database
        inria.print(System.out);
        
        
        // Step 10: here's another way to do this same translation
        //          create another empty persons database + empty tables
        DB inria2 = new DB("inria2",outSchema);
        Table male2 = inria2.getTableEH("male");
        Table female2 = inria2.getTableEH("female");
        
        // Step 11: fill in father, mother, sons, and daughter tuples
        theWork(fam,"fatherid",mem,"mid",male2);
        theWork(fam,"motherid",mem,"mid",female2);
        theWork(fam,"id",mem,"sonOf",male2);
        theWork(fam,"id",mem,"daughterOf",female2);
        
        // Step 12: output database
        inria2.print(outputFileName);
    }
    
    // this does the work: fam is the family table, mem is the member table
    // famKey is the family join key, memKey is the member join key
    // and result = table in which result is to be placed
    static void theWork(Table fam, String famKey, Table mem, String memKey, Table result) {
        Table j = Table.join(fam, famKey, mem, memKey);
        for (Tuple jt : j.tuples()) {
            String id = jt.get("member.mid");
            String fullName = jt.get("member.firstName")+ " " +jt.get("family.lastName");
            result.addTuple(id,fullName);
        }
    }
}
