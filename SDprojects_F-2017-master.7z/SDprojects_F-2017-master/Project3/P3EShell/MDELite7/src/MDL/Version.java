package MDL;

/**
 * MDL program that outputs the version of MDELite
 **/

public class Version {
    
    /**
     * prints the version of MDELite
     * @param args -- ignored
     */
    public static void main(String... args) {
        System.out.println("MDELite version 7.1m");
    }
    
}
