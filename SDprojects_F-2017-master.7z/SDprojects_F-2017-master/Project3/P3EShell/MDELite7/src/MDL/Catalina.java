package MDL;

public class Catalina extends BootMDELite.Common {

    public static void main(String... args) {
        main(Catalina.class, args, state, domains.values(), maps.values());
    }

    static enum domains implements IEnum {
        state(".state.violet"),
        fsm(".fsm.pl"),
        meta(".meta.pl"),
        java(".java"),
        ;

        public String data; // file type ending

        private domains(String end) {
            this.data = end;
        }

        @Override
        public String getEnd() {
            return data;
        }

        public static domains[] list(domains... args) {
            return args;
        }
    };

    static enum arrows implements PEnum {
        fsmConform( new Triple(
          a -> { BootMDELite.CategoryConform.main(a); return null; },  // FIX
          domains.list(domains.fsm),
          new domains[0])),
        metaConform( new Triple(
          a -> { BootMDELite.MetaConform.main(a); return null; },
          domains.list(domains.meta),
          new domains[0])),
        parse( new Triple(
          a -> { Violett.StateParser.main(a); return null; },
          domains.list(domains.state),
          domains.list(domains.fsm))),
        m2m( new Triple(
          a -> { BootMDELite.fsm2meta.main(a); return null; },
          domains.list(domains.fsm),
          domains.list(domains.meta))),
        m2t( new Triple(
          a -> { BootMDELite.meta2java.main(a); return null; },
          domains.list(domains.meta),
          domains.list(domains.java))),
        ;

        private final Triple data;

        private arrows(Triple data) { this.data = data;} 

        @Override
        public Triple get() { return data; }

        @Override
        public IEnum[] getArray(int size) { return new domains[size]; }
    }

    static enum maps implements PEnum {
        convert( new Triple(
          a -> { Catalina.convert(a); return null; },
          domains.list(domains.state),
          domains.list(domains.java))),
        validateViolet( new Triple(
          a -> { Catalina.validateViolet(a); return null; },
          domains.list(domains.state),
          new domains[0])),
        validateMeta( new Triple(
          a -> { Catalina.validateMeta(a); return null; },
          domains.list(domains.state),
          new domains[0])),
        ;

        private final Triple data;

        private maps(Triple data) { this.data = data;} 

        @Override
        public Triple get() { return data; }

        @Override
        public IEnum[] getArray(int size) { return new domains[size]; }
    }

    public static void convert(String[] args) {
        enoughCommandLineArguments(maps.convert, args);

        invoke(arrows.parse, state);
        invoke(arrows.fsmConform, state);
        invoke(arrows.m2m, state);
        invoke(arrows.metaConform, state);
        invoke(arrows.m2t, state);
        completed(maps.convert);
    }

    public static void validateViolet(String[] args) {
        enoughCommandLineArguments(maps.validateViolet, args);

        invoke(arrows.parse, state);
        invoke(arrows.fsmConform, state);
        completed(maps.validateViolet);
    }

    public static void validateMeta(String[] args) {
        enoughCommandLineArguments(maps.validateMeta, args);

        invoke(arrows.parse, state);
        invoke(arrows.fsmConform, state);
        invoke(arrows.m2m, state);
        invoke(arrows.metaConform, state);
        completed(maps.validateMeta);
    }

}

