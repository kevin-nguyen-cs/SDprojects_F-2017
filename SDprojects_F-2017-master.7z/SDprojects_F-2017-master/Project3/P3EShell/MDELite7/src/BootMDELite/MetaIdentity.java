package BootMDELite;

public class MetaIdentity {
    
    public static void main(String... args) {
        Identity.main(".meta.pl", args);
    }
    
}
