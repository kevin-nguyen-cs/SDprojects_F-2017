package BootMDELite;

import PrologDB.ErrorReport;
import PrologDB.Table;
import PrologDB.Tuple;
import java.util.LinkedList;

/**
 * code that is shared at catalina-run-time and application-run-time
 */
public class Shared {

    /**
     * list of command-line (names-of-domain) inputs
     */
    public static LinkedList<String> inputs;

    /**
     * list of names-of-non-temporary-domains that are produced as output
     */
    public static LinkedList<String> nonTempOutputs;

    /**
     * list of names-of-domains that are produced as output
     */
    public static LinkedList<String> outputs;

    /** given the String of a path (arrows separated by ';'), the arrow
     * table and the node table, compute (into the static lists above)
     * of domain names that define the inputs, outputs, and non-temporary-outputs
     * 
     * @param path -- string of path "arrow1;arrow2;...;arrowN"
     * @param arrow -- arrow table
     * @param domain -- node or domain table
     */
    public static void computeInOut(String path, Table arrow, Table domain) {
        String[] paths = path.replace(" ","").split(MetaConform.pathSeparator);
        inputs = new LinkedList<>();
        outputs = new LinkedList<>();
        nonTempOutputs = new LinkedList<>();
        ErrorReport er = new ErrorReport();
        for (String p : paths) {
            Tuple a = arrow.getFirstEH((Tuple t) -> t.is("name", p));
            String[] sig = a.get("domainInputs").split(",");
            for (String s : sig) {
                if (inputs.contains(s) || outputs.contains(s)) {
                    continue;
                }
                inputs.add(s);
                // now check -- the inputs should not include temporary results
                boolean tmp = domain.getFirstEH((Tuple t) -> t.is("name", s)).is("temp", "true");
                if (tmp) {
                    er.add("input from temporary domain %s is required", s);
                }
            }
            String out = a.get("domainOutput");
            outputs.add(out);
            if (domain.getFirstEH((Tuple t) -> t.is("name", out)).is("temp", "false")) {
                nonTempOutputs.add(out);
            }
        }
        // now check -- the inputs should not include temporary results
        er.printReport(System.out);
    }

}
