package BootMDELite;

import MDELite.Marquee2Arguments;
import PrologDB.DB;
import PrologDB.DBSchema;
import PrologDB.Table;
import PrologDB.Tuple;


public class CatCSVParser {
    
    /** eventually this is to be a parser from X.cat.spec to X.meta.pl
     * @param args  X.cat.spec  X.meta.pl
     */
    public static void main(String... args) {
        // Step 1: standard marquee processing
        Marquee2Arguments mark = new Marquee2Arguments(fsm2meta.class, ".metadir", ".meta.pl", args);
        String inputDirName = mark.getInputFileName();
        String outputFileName = mark.getOutputFileName();
        String AppName = mark.getAppName(inputDirName);
        
        // Step 2: read the tables
        Table dTable = Table.readTable(inputDirName+"/domain.csv");
        Table aTable = Table.readTable(inputDirName+"/arrow.csv");
        Table pTable = Table.readTable(inputDirName+"/path.csv");
        
        // Step 3: initialize meta tables
        DBSchema ms = DBSchema.readSchema(MDELite.Utils.MDELiteHome()+"libpl/meta.schema.pl");
        DB mdb = new DB(AppName,ms);
        Table dtab = mdb.getTable("domain");
        Table atab = mdb.getTable("arrow");
        Table ptab = mdb.getTable("path");
        
        // Step 4: translate tables
        dTable.stream().forEach(t-> dtab.add( new Tuple(dtab).copy(t)));
        aTable.stream().forEach(t-> atab.add( new Tuple(atab).copy(t)));
        pTable.stream().forEach(t-> ptab.add( new Tuple(ptab).copy(t)));
        
        // Step 5: output file
        mdb.print(outputFileName);
    }
}
