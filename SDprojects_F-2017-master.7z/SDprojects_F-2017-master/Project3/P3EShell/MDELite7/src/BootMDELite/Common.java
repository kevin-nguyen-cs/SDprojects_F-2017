package BootMDELite;

import MDELite.Marquee2Arguments;
import java.util.HashMap;
import java.util.function.UnaryOperator;

/**
 * 1-class framework that contains all the commonalities across all catalina-
 * bootstrapped files
 */
public abstract class Common {

    /**
     * currency state -- a set of (domain, name-of-current-file-in-this domain)
     * pairs idea taken from ancient codasyl databases -- good enough for me.
     */
    public static HashMap<String, String> state = new HashMap<>();

    /**
     * contains method call to MDELite transformation and domain inputs and
     * outputs for this call
     */
    public static class Triple {

        /**
         * method is a unary operator that calls an arrow
         */
        public final UnaryOperator<String[]> method;
        /**
         * array of domain name inputs
         */
        public final IEnum[] inputs;
        /**
         * array of domain name outputs; if no output, domain[0] is present
         */
        public final IEnum[] output;

        /**
         * constructor of a Triple
         *
         * @param method -- unary operator
         * @param inputs -- array of inputs
         * @param output -- array of outputs
         */
        public Triple(UnaryOperator<String[]> method, IEnum[] inputs, IEnum[] output) {
            this.method = method;
            this.inputs = inputs;
            this.output = output;
        }
    }

    /**
     * used for domains -- each enum is a domain with a program postfix
     * (.meta.pl)
     */
    public static interface IEnum {

        /**
         * @return postfix end of domain
         */
        String getEnd();

        /**
         * @return name of enum
         */
        String name();
    }

    /**
     * used for arrows (primitives and paths) -- each enum is an arrow with its
     * enum input domains(s) and output domain(s).
     */
    public static interface PEnum {

        /**
         * @return Triple associated with this PEnum
         */
        Triple get();

        /**
         * @return return name of this PEnum
         */
        String name();

        /**
         * @param size -- size of array to return
         * @return -- PEnum array of size
         */
        IEnum[] getArray(int size);
    }

    /**
     * @param a input arrow
     * @return the union of all input and output domains of an input arrow
     */
    public static IEnum[] getAllArgTypes(PEnum a) {
        IEnum[] inputs = a.get().inputs;
        IEnum[] output = a.get().output;
        int ilen = inputs.length;
        IEnum[] result = a.getArray(ilen + output.length);
        for (int i = 0; i < inputs.length; i++) {
            result[i] = inputs[i];
        }
        for (int i = 0; i < output.length; i++) {
            result[ilen + i] = output[0];
        }
        return result;
    }

    // values set by main
    static Class c;
    static PEnum[] mmaps;
    static String AppName;

    /**
     * general marquee for all catalina-generated programs
     *
     * @param msg -- specialized message that is to be reported (as in an error)
     * in addition to general marquee
     */
    public static void marquee(String msg) {
        if (msg != null) {
            System.out.format("   -----> %s\n\n", msg);
        }

        System.out.format("Usage: %s option args...\n", c.getName());
        for (PEnum o : mmaps) {
            Triple t = o.get();
            String inputs = makeStr(t.inputs);
            String outputs = makeStr(t.output);
            if (outputs.equals("")) {
                outputs = "T/F";
            }
            System.out.format("       %-15s   %s -> %s\n", o, inputs, outputs);
        }
        System.exit(0);
    }

    private static String makeStr(IEnum[] l) {
        String result = "";
        String comma = "";
        for (IEnum s : l) {
            result = result + comma + s.name();
            comma = ",";
        }
        return result;
    }

    /**
     * general main() call for all catalina-generated files
     *
     * @param c -- class of catalina-generated file
     * @param args -- main(args) parameter of catalina-generated file
     * @param state -- "currency state" of application
     * @param domains -- array of application domains
     * @param maps -- array of application maps (command-line path options)
     */
    public static void main(Class c, String[] args, HashMap<String, String> state, IEnum[] domains,
            PEnum[] maps) {
        Common.c = c;
        Common.mmaps = maps;
        String map2Invoke = LoadArgumentsIntoState(args, state, domains);
        Marquee2Arguments mark = new Marquee2Arguments();
        Common.AppName = mark.getAppName(args[1]);

        // now invoke application method
        for (PEnum m : maps) {
            if (m.name().equals(map2Invoke)) {
                m.get().method.apply(args);
                return;
            }
        }
        marquee("unrecognizable command '" + map2Invoke + "'");
    }

    /**
     * method that is called to print path execution has been completed
     *
     * @param completedPath -- PEnum object of path/map just completed
     */
    public static void completed(PEnum completedPath) {
        System.out.format("       %s %s -> %s .....  completed!\n", completedPath.name(),
                toString(completedPath.get().inputs),
                toString(completedPath.get().output));
    }

    /**
     * does selected path have enough command-line parameters? if not display
     * marquee
     *
     * @param path or map object
     * @param args of main(args)
     */
    public static void enoughCommandLineArguments(PEnum path, String[] args) {
        IEnum[] inputs = path.get().inputs;
        if ((args.length - 1) != inputs.length) {
            String msg = String.format("%d file arguments expected for option %s, only %d were given\n", inputs.length, path.name(), args.length - 1);
            marquee(msg);
        }
    }

    /**
     * invoke path (map)
     *
     * @param p -- path a.k.a. map object
     * @param state -- currency state
     */
    public static void invoke(PEnum p, HashMap<String, String> state) {
        IEnum[] argtypes = getAllArgTypes(p);
        String[] arguments = SetArguments(state, argtypes);
        p.get().method.apply(arguments);
        IEnum[] out = p.get().output;
        IEnum[] in = p.get().inputs;
        for (int i = 0; i < out.length; i++) {
            IEnum e = p.get().output[i];
            state.put(e.name(), arguments[in.length + i]);
        }
    }

    /**
     * convert an array of domains to a string
     *
     * @param array of domains
     * @return -- string of their names
     */
    static String toString(IEnum[] array) {
        String result = "";
        for (IEnum d : array) {
            result = result + d + " ";
        }
        return result;
    }

    /**
     * load command line arguments into the currency-state vector
     *
     * @param args -- from main(args)
     * @param state -- currency state of application
     * @param domains -- array of all possible domains
     * @return
     */
    private static String LoadArgumentsIntoState(String[] args,
            HashMap<String, String> state, IEnum[] domains) {
        if (args.length < 2) {
            marquee(null);
        }
        for (int i = 1; i < args.length; i++) {
            boolean recognized = false;
            for (IEnum d : domains) {
                if (args[i].endsWith(d.getEnd())) {
                    state.put(d.name(), args[i]);
                    recognized = true;
                    break;
                }
            }
            if (!recognized) {
                throw BootError.toss(BootError.unrecognizedCommandLineArg, args[i]);
            }
        }
        return args[0]; // return command-line map to invote
    }

    /**
     * create the command-line sequence of arguments taken from currency state
     * and specified by their domain types
     *
     * @param state -- currencyState
     * @param domainTypes -- domains, in order, of argument requirement
     * @return
     */
    private static String[] SetArguments(HashMap<String, String> state, IEnum... domainTypes) {
        int len = domainTypes.length;
        String[] args = new String[len];
        for (int i = 0; i < len - 1; i++) {
            String at = state.get(domainTypes[i].name());
            if (at == null) {
                throw BootError.toss(BootError.domainHasNullCurrencyValue);
            }
            args[i] = AppName + domainTypes[i].getEnd();
        }
        args[len - 1] = AppName + domainTypes[len - 1].getEnd();
        return args;
    }
}
