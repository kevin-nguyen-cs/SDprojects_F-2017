package PrologDB;

import java.util.Stack;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * common constraints that arise in MDELite tables
 * @author don
 */
public class Constraints {

    /**
     * verify that all rows in table t have column with unique values
     * @param t table
     * @param column name of column that is unique
     * @param er error reporter
     */
    public static void isUnique(Table t, String column, ErrorReport er) {
        Unique u = new Unique(t, column, er);
        t.stream().forEach(s -> u.add(s));
    }

    /**
     * ensure that t.column2r points to a legit row in r.columnrid, er is 
     * error reporter
     * @param t  table with foreign key
     * @param column2r column with foreign key
     * @param r table that is referenced
     * @param columnrid column that is referenced in r
     * @param er error reporter
     */
    public static void isLegit(Table t, String column2r, Table r, String columnrid, ErrorReport er) {
        Table rsmall = r.project(columnrid);
        Table rejects = Table.antiSemijoin(t, column2r, rsmall, columnrid);
        String tname = t.getName();
        rejects.stream().forEach(k -> er.add("%s(%s...) has %s='%s' : not a legal reference",
                tname, k.getId(), column2r, k.get(column2r)));
    }
    
    public static void isLegit(Table t, String column2r, Table r, String columnrid, ErrorReport er, Function<Tuple,String> emsg) {
        Table rsmall = r.project(columnrid);
        Table rejects = Table.antiSemijoin(t, column2r, rsmall, columnrid);
        rejects.stream().forEach(k -> er.add(emsg.apply(k)));
    }

    /**
     * implies: ifpred implies thenpred; violations are reported in error reporter
     * @param t  table
     * @param ifpred "if" predicate true 
     * @param thenpred "then" predicate that must be true (otherwise violation)
     * @param expl -- String explanation "%s(%s...) has  ...violated" where ...violated is filled in
     * @param er -- error reporter
     */
    public static void implies(Table t, Predicate<Tuple> ifpred, Predicate<Tuple> thenpred,
            String expl, ErrorReport er) {
        String tname = t.getName();
        String fmt = "%s(%s...) has " + expl;
        for (Tuple r : t.tuples()) {
            if (ifpred.test(r)) {
                if (thenpred.negate().test(r)) {
                    String rid = r.getId();
                    er.add(fmt, tname, rid);
                }
            }
        }
    }

    /**
     * ifpred -- then error
     * @param t  table
     * @param ifpred "if" predicate true (then violation)
     * @param expl -- String explanation "tuple id=%s in %s: ... violated" where ... is filled in
     * @param er -- error reporter
     */
    public static void iftest(Table t, Predicate<Tuple> ifpred,
            String expl, ErrorReport er) {
        implies(t, ifpred, r -> false, expl, er);
    }
    
    static final String par = "par";
    static final String chd = "chd";
    
    /**
     * @return empty cycle table (par,chd)
     */
    public static Table makeCycleTable() {
        TableSchema ts = new TableSchema("cycleTable");
        ts.addColumns("par","chd");
        Table ct = new Table(ts);
        return ct;
    }
    
    
    /**
     * determines if there are cycles in a cycle table (par,chd), where
     * par = parent id, and chd = child id
     * @param t  (par,chd) table
     * @param er error reporter to collect errors
     */
    public static void cycleCheck(Table t, ErrorReport er) {
        Stack<String> stack = new Stack<>();
        for (Tuple r : t.tuples()) {
            String start = r.get(par);
            if (cycleCheck(t, start, start, stack)) {
                String result = start;
                while (!stack.empty()) {
                    result = stack.pop() + "," + result ;
                }
                er.add("Cycle found: [%s,%s]", start,result);
                return;
            }
            stack.clear();
        }
    }

    private static boolean cycleCheck(Table t, String end, String next, Stack<String> stack) {
        Table smaller = t.filter(row->row.is(par,next)).filter(row -> !row.is(chd, ""));
        for (Tuple s : smaller.tuples()) {
            String spar = s.get(chd);
            if (!spar.equals(end)) {
                stack.push(spar);
                if (!cycleCheck(t, end, spar, stack)) {
                    stack.pop();
                } else {
                    return true;
                }
            }
            else return true;
        }
        return false;
    }
}
