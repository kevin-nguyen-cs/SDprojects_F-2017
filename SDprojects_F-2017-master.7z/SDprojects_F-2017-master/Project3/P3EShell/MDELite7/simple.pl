table(simple,["Id","ab","cd"]).
simple('i1','ab','cd').
simple('i2','ef','gh').
simple('i3','ij','kl').

