package GatesApp;

public enum Value { TRUE, UNKNOWN, FALSE }
