package Errors;

public class NoValueSet extends RuntimeException {
    public NoValueSet(String error) {
        super(error);
    }
}
