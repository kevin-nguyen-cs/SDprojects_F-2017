package Pins;

import java.util.*;
import logicGates.*;
import GatesApp.*;
import logicGates.Wire;

public class OutputPin {
    Value value;
    public String name;
    Gate outputOf;
    //AbstractList<Wire> wiresFrom;
    LinkedList<Wire> wiresFrom;
    
    public OutputPin(String name, Gate parent) {
        wiresFrom = new LinkedList<Wire>();
        //AbstractList<Wire> wiresFrom = new LinkedList<Wire>();
        this.name = name;
        outputOf = parent;
    }
    
    public void addWire(Wire w) {
        wiresFrom.add(w);
    }
    
    public String toString() {
        return outputOf.name+ "->" + name;
    }
    
    public String nameOfGate() {
        return outputOf.name;
    }
    
    @Feature(Feature.constraints)
    
    public boolean isUsed() {
        if (wiresFrom.isEmpty()) {
            return false;
        }
        return true;
    }
    
    @Feature(Feature.eval)
    
    public Value getValue() {
        
        Value thisValue;
        
        String type = outputOf.getClass().getName();
        
        if (type.equals("logicGates.And")) {
            thisValue = ((And)outputOf).getValue();
        } else if (type.equals("logicGates.Or")) {
            thisValue = ((Or)outputOf).getValue();
        } else if (type.equals("logicGates.InputPort")) {
            thisValue = ((InputPort)outputOf).getValue();
        } else {
            thisValue = ((Not)outputOf).getValue();
        }
        
        return thisValue;

    }
}
