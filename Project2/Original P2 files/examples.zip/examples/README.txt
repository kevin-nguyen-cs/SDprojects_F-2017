to convert these ugly Violet XML files into vpl databases.

> java Violett.ClassParser X.class.violet X.vpl.pl

for all X.class.violet files in this directory
